# Velará Products — Catalogue & WhatsApp Ordering Website

A responsive, static storefront for a cosmetics brand. It includes:
- Product catalogue with photos, descriptions, categories and LKR prices
- Search and category filters
- Shopping bag/cart with quantity controls
- Customer name, phone, delivery address and optional order note
- WhatsApp order message generated for **+94 70 347 1440**
- No payment processing and no server-side storage of customer details

## Important before publishing

1. `products.js` currently contains **sample product names, descriptions, and prices**. Replace them with accurate details for your real products before going live.
2. Add your real product photos to the `images/` folder and set each product's `image` value in `products.js`, for example `image: "images/velara-face-cream.jpg"`.
3. Use product photos you own or are permitted to use. Optimise images for the web (ideally WebP/JPEG, under about 500 KB each).
4. Confirm prices, product sizes, stock, delivery fees, and product claims before publishing.
5. This is a WhatsApp ordering catalogue, not a payment gateway. Orders are not submitted until the customer presses **Send** in WhatsApp. The site does not save checkout data or send order notifications by itself.
6. Hosting terms and free-plan limits can change. Do not collect card details on this static site.

## Edit product details

Open `products.js`. Each product object follows this pattern:

```js
{
  id: "unique-product-id",
  name: "Product Name",
  category: "Face Care",
  price: 1500,
  size: "50 g",
  badge: "New",
  description: "A short accurate product description.",
  image: "images/product-name.jpg"
}
```

- `id` must be unique and should not contain spaces.
- `price` is a number in Sri Lankan rupees.
- `category` creates the category filter automatically.
- `badge` can be `""` if you do not need a badge.
- `image` can be `""` to display a decorative placeholder.

To add another product, copy an object, change its details and save. To remove a product, remove its object from the array. Keep commas between objects.

## Add product photos

1. Put each photo in the `images/` folder.
2. Use simple filenames without spaces, e.g. `velara-face-cream.jpg`.
3. Set the matching `image` path in `products.js`.
4. Commit and push the changes to GitHub; Cloudflare Pages will redeploy if connected to your repository.

## Preview locally

Open `index.html` in a modern browser. If your browser restricts local files, run a simple local server from this folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish free with GitHub + Cloudflare Pages

GitHub is used to store and edit the code. Use Cloudflare Pages to host the commercial website.

### A. Put the project on GitHub

1. Sign in at https://github.com/ and create a new repository, e.g. `velara-products`.
2. Upload the contents of this folder to the repository root. Ensure `index.html`, `styles.css`, `app.js`, and `products.js` are at the top level (not hidden inside another folder).
3. Commit the files.

### B. Deploy on Cloudflare Pages

1. Create/sign in to a Cloudflare account at https://dash.cloudflare.com/.
2. Open **Workers & Pages** (the dashboard wording can vary) and choose to create a Pages project connected to Git.
3. Connect GitHub and select `velara-products`.
4. For a plain HTML site, use no framework / **None** as the framework preset. If a build command is required, use `exit 0`. Set the output directory to `/` or the repository root as requested by the current setup UI.
5. Save and deploy. Cloudflare should provide a `*.pages.dev` address.
6. Open the published address on desktop and mobile, test search and cart, then place a test order and confirm the WhatsApp message is correct.

Official docs:
- Cloudflare Pages: https://developers.cloudflare.com/pages/
- Deploy static HTML: https://developers.cloudflare.com/pages/framework-guides/deploy-anything/
- GitHub repositories: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository

### C. Update later

Edit `products.js` or replace photos in `images/`, commit and push to GitHub. Cloudflare Pages will build/deploy the new version automatically when connected to the repo.

## Project files

- `index.html` — page structure
- `styles.css` — layout, luxury theme and responsive styling
- `app.js` — search, filters, cart and WhatsApp checkout
- `products.js` — editable product list
- `images/` — place your product photos here
