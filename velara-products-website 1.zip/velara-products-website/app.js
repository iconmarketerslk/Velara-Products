/* Velará Products storefront. No customer checkout details are stored. */
(() => {
  "use strict";
  const WHATSAPP_NUMBER = "94703471440"; // International format, digits only
  const money = value => "Rs. " + Number(value).toLocaleString("en-LK", {maximumFractionDigits: 2});
  const $ = id => document.getElementById(id);
  const state = { cart: {}, category: "All", search: "" };

  const grid = $("product-grid"), categoryList = $("category-list");
  const drawer = $("cart-drawer"), overlay = $("overlay");
  let toastTimer;

  function safeImage(image, name) {
    if (!image) return `<div class="product-placeholder"><div class="placeholder-jar">VELARÁ</div><div class="placeholder-name">${escapeHtml(name)}</div></div>`;
    return `<img src="${escapeAttr(image)}" alt="${escapeAttr(name)}" loading="lazy" onerror="this.parentElement.innerHTML='<div class=&quot;product-placeholder&quot;><div class=&quot;placeholder-jar&quot;>VELARÁ</div><div class=&quot;placeholder-name&quot;>Add product photo</div></div>'">`;
  }
  function escapeHtml(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function escapeAttr(s) { return escapeHtml(s); }
  function allCategories() { return ["All", ...new Set(PRODUCTS.map(p => p.category).filter(Boolean))]; }

  function renderCategories() {
    categoryList.innerHTML = allCategories().map(c =>
      `<button class="category-button ${state.category === c ? "active" : ""}" data-category="${escapeAttr(c)}">${escapeHtml(c)}</button>`
    ).join("");
  }
  function filteredProducts() {
    return PRODUCTS.filter(p => (state.category === "All" || p.category === state.category)
      && `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(state.search.toLowerCase()));
  }
  function renderProducts() {
    const products = filteredProducts();
    grid.innerHTML = products.map(p => `
      <article class="product-card">
        <div class="product-photo">
          ${safeImage(p.image, p.name)}
          ${p.badge ? `<span class="product-badge">${escapeHtml(p.badge)}</span>` : ""}
          <button class="quick-add" data-add="${escapeAttr(p.id)}" aria-label="Add ${escapeAttr(p.name)} to bag">+</button>
        </div>
        <div class="product-info">
          <p class="product-category">${escapeHtml(p.category)}</p>
          <h3>${escapeHtml(p.name)}</h3>
          <p class="product-description">${escapeHtml(p.description)}</p>
          <div class="product-bottom"><div><div class="product-price">${money(p.price)}</div><div class="product-size">${escapeHtml(p.size || "")}</div></div>
          <button class="add-label" data-add="${escapeAttr(p.id)}">ADD TO BAG +</button></div>
        </div>
      </article>`).join("");
    $("empty-state").classList.toggle("hidden", products.length !== 0);
  }
  function cartEntries() {
    return Object.entries(state.cart).map(([id, quantity]) => ({product: PRODUCTS.find(p => p.id === id), quantity}))
      .filter(item => item.product && item.quantity > 0);
  }
  function cartCount() { return cartEntries().reduce((sum, item) => sum + item.quantity, 0); }
  function cartTotal() { return cartEntries().reduce((sum, item) => sum + item.product.price * item.quantity, 0); }
  function renderCart() {
    const entries = cartEntries();
    $("cart-count").textContent = cartCount();
    $("drawer-count").textContent = `(${cartCount()})`;
    $("cart-subtotal").textContent = money(cartTotal());
    $("cart-empty").classList.toggle("hidden", entries.length > 0);
    $("cart-summary").classList.toggle("hidden", entries.length === 0);
    $("cart-items").innerHTML = entries.map(({product:p, quantity:q}) => `
      <div class="cart-line">
        <div class="cart-thumb">${p.image ? `<img src="${escapeAttr(p.image)}" alt="">` : `<span>VELARÁ</span>`}</div>
        <div><h4>${escapeHtml(p.name)}</h4><div class="line-price">${money(p.price)} ${p.size ? "· " + escapeHtml(p.size) : ""}</div>
          <div class="quantity-control"><button data-qty="${escapeAttr(p.id)}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${q}</span><button data-qty="${escapeAttr(p.id)}" data-delta="1" aria-label="Increase quantity">+</button></div>
          <button class="remove-item" data-remove="${escapeAttr(p.id)}">Remove</button>
        </div><div class="cart-line-total">${money(p.price*q)}</div>
      </div>`).join("");
  }
  function showToast(message) {
    $("toast").textContent = message;
    $("toast").classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2200);
  }
  function addToCart(id) {
    const p = PRODUCTS.find(p => p.id === id);
    if (!p) return;
    state.cart[id] = (state.cart[id] || 0) + 1;
    renderCart(); showToast(`${p.name} added to your bag`);
  }
  function openCart() {
    drawer.classList.add("open"); drawer.setAttribute("aria-hidden", "false");
    overlay.classList.remove("hidden"); document.body.style.overflow = "hidden";
  }
  function closeCart() {
    drawer.classList.remove("open"); drawer.setAttribute("aria-hidden", "true");
    overlay.classList.add("hidden"); document.body.style.overflow = "";
  }

  grid.addEventListener("click", event => {
    const btn = event.target.closest("[data-add]");
    if (btn) addToCart(btn.dataset.add);
  });
  categoryList.addEventListener("click", event => {
    const btn = event.target.closest("[data-category]");
    if (btn) { state.category = btn.dataset.category; renderCategories(); renderProducts(); }
  });
  $("search-input").addEventListener("input", event => { state.search = event.target.value.trim(); renderProducts(); });
  $("open-cart").addEventListener("click", openCart);
  $("close-cart").addEventListener("click", closeCart);
  $("continue-shopping").addEventListener("click", closeCart);
  overlay.addEventListener("click", closeCart);
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeCart(); });
  $("cart-items").addEventListener("click", event => {
    const qty = event.target.closest("[data-qty]");
    const remove = event.target.closest("[data-remove]");
    if (qty) {
      const id = qty.dataset.qty;
      state.cart[id] = (state.cart[id] || 0) + Number(qty.dataset.delta);
      if (state.cart[id] <= 0) delete state.cart[id];
      renderCart();
    } else if (remove) {
      delete state.cart[remove.dataset.remove]; renderCart();
    }
  });
  $("checkout-form").addEventListener("submit", event => {
    event.preventDefault();
    const entries = cartEntries();
    if (!entries.length) { showToast("Your bag is empty."); return; }
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name") || "").trim();
    const phone = String(form.get("phone") || "").trim();
    const address = String(form.get("address") || "").trim();
    const note = String(form.get("note") || "").trim();
    if (!name || !phone || !address) { showToast("Please complete your delivery details."); return; }

    const lines = [
      "Hello Velará Products! I'd like to place an order.",
      "",
      ...entries.map(({product:p, quantity:q}, i) => `${i+1}. ${p.name} × ${q} — ${money(p.price*q)}`),
      "",
      `Subtotal: ${money(cartTotal())}`,
      "Delivery fee: To be confirmed",
      "",
      `Customer name: ${name}`,
      `Phone: ${phone}`,
      `Delivery address: ${address}`,
      ...(note ? [`Order note: ${note}`] : []),
      "",
      "Please confirm availability, delivery charges and my order. Thank you!"
    ];
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(lines.join("\n"))}`;
    window.open(url, "_blank", "noopener,noreferrer");
  });

  $("footer-whatsapp").href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hello Velará Products! I'd like to ask about your products.")}`;
  $("year").textContent = new Date().getFullYear();
  renderCategories(); renderProducts(); renderCart();
})();
