/*
  VELARÁ PRODUCTS CATALOGUE
  Edit this file to add, remove, or update products.
  - id: unique short identifier
  - price: number in Sri Lankan rupees (LKR)
  - category: used by the category filters
  - image: path inside the images/ folder, e.g. "images/face-cream.jpg"
  - image: leave as "" to show the designed placeholder
  Replace the sample products and prices before publishing.
*/
const PRODUCTS = [
  {
    id: "face-cream",
    name: "Velará Face Cream",
    category: "Face Care",
    price: 3650,
    size: "50 g",
    badge: "Everyday essential",
    description: "A daily skincare step for a soft, cared-for feeling.",
    image: "images/velara50.png"
  },
  {
    id: "face-cream2",
    name: "Velará Face Cream 25g",
    category: "Face Care",
    price: 2850,
    size: "25 g",
    badge: "Everyday essential",
    description: "A daily skincare step for a soft, cared-for feeling.",
    image: "images/velara25.png"
  },
  {
    id: "Ruwanari",
    name: "Ruwanari Cream",
    category: "Body Care",
    price: 3450,
    size: "50 g",
    badge: "Everyday essential",
    description: "A daily skincare step for a soft, cared-for feeling.",
    image: "images/ruwanari.png"
  },
  {
    id: "Tea-Bag",
    name: "PRANA 30 Days Tea Program",
    category: "Health Care",
    price: 4250,
    size: "750 g",
    badge: "Everyday essential",
    description: "A daily health care and improve your youngness",
    image: "images/teawomen.png"
  },
  {
    id: "body-lotion",
    name: "Ruwanari Body Lotion",
    category: "Body Care",
    price: 3400,
    size: "300 ml",
    badge: "",
    description: "A daily body-care essential for firm, smooth-feeling skin.",
    image: "images/ruwanarilotion.png"
  }
];
